# Profile657 #

A simple "vibe coded" Django signup and login app.

## Requirements ##

* Django

## Tested with ##

```
Python==3.14
django==6.0.8
```

## Installation ###

### Install with pip ###

``` bash
pip install -U git+https://github.com/oscfr657/profile657.git@main
```

### Django settings ###

In the settings file

add to the INSTALLED_APPS

``` python
INSTALLED_APPS = [
    'django.contrib.auth',
    'profile657',
]
```

and 

``` python
PROFILE657_SIGNUP_LOCKED = False
```

### Django url ###

To the django projects' url.py add

``` python
from django.urls import path, include
```

and

``` python
urlpatterns += [
    path('', include('profile657.urls')),
    path('', include('django.contrib.auth.urls')),
]
```

### Database configuration ###

``` bash
python manage.py makemigrations
python manage.py migrate
```

### Collectstatic ###

``` bash
python manage.py collectstatic
```

## For development ##

### Create a new release ###

#### Make migrations ####

``` bash
python manage.py makemigrations
python manage.py migrate
```

#### Run black ####

``` bash
python3 -m venv env
source env/bin/activate
python -m pip install black
python -m black . -S -t py312 -t py313 -t py314 --extend-exclude .migrations --diff
python -m black . -S -t py312 -t py313 -t py314 --extend-exclude .migrations
```

#### Run tests ####

``` bash 
python manage.py test profile657
```

Update version in VERSION.txt

Update CHANGELOG.md

#### Build release ####

``` bash
python -m pip install build
python -m build --sdist
```

#### Publish to Git ####

``` bash
git commit -a -m 'Changelog message.'
git push
```

## TODO: ##

feat: Add invite only functionality